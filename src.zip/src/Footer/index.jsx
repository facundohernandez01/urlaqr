import React, { useState } from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { IconButton, Grid, List, ListItem, ListItemText } from '@mui/material';
import { Email, Phone, Room } from '@mui/icons-material';

const AnyReactComponent = ({ text }) => <div>{text}</div>;

function Footer({ handleClickOpen, open }) {
  const [center, setCenter] = useState({ lat: 37.7749, lng: -122.4194 });
  const [zoom, setZoom] = useState(13);

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar
        position="static"
        sx={{
          backgroundColor: '#212121',
          height: 400,
          bottom: 0,
        }}
      >
    
          <Grid container spacing={2} sx={{ mt: 4 }}>

            <Grid item xs={12} sm={6} md={3}>
              <Typography variant="h6" sx={{ mb: 2 }}>Categorías</Typography>
              <List>
                <ListItem button>
                  <ListItemText primary="Ofertas" />
                </ListItem>
                <ListItem button>
                  <ListItemText primary="Refrigeración" />
                </ListItem>
                <ListItem button>
                  <ListItemText primary="Accesorios" />
                </ListItem>
                <ListItem button>
                  <ListItemText primary="Tecnología" />
                </ListItem>
              </List>
            </Grid>

            <Grid item xs={12} sm={6} md={3}>

              <Typography variant="h6" sx={{ mb: 2 }}>Contáctanos</Typography>
              <List>
                <ListItem>
                <Room sx={{ mr: 1 }} />

                  <ListItemText primary="Av. Siempre Viva 123, Springfield" />
                </ListItem>
                <ListItem>
                  <Phone sx={{ mr: 1 }} />
                  <ListItemText primary="555-1234" />
                </ListItem>
                <ListItem>
                  <Email sx={{ mr: 1 }} />
                  <ListItemText primary="info@flashstore.com" />
                </ListItem>
              </List>
            </Grid>
            
            </Grid>

      </AppBar>
    </Box>
  );
}

export default Footer;
